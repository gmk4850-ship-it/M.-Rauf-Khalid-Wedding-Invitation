RAUF & LAIBA — WALIMA INVITATION
Mobile-friendly single-page interactive invitation.

Included:
- Animated envelope with R & L seal
- Walima-only invitation details
- Google Maps location link
- Click-to-call and WhatsApp RSVP for both contacts
- RSVP form that opens WhatsApp with a prepared message
- Add-to-calendar (.ics) download

Publish:
1. Upload index.html to the root of your GitHub repository (replace the old index.html).
2. Keep GitHub Pages enabled for the branch/folder where index.html is stored.
3. Open your GitHub Pages URL on your phone to test.
No build step is required. Google Fonts requires an internet connection; the page still works with fallback fonts.
